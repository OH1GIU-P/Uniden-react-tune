﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using System.IO.Ports;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        string dataRX = string.Empty;
        string freq = string.Empty;
        bool rx = false;
        bool tcpConnect = false;
        const string APP_TITLE = "SDR# Uniden react tune";
        const string IP = "127.0.0.1";
        const string UNIDEN_CMD = "GLG\r";
        const string GLG_SQL_CLOSED = "GLG,,,,,,,,,";
        const string GLG_SQL_CLOSE_MSG = "GLG...";
        const string NO_COM_PORT_MSG = "No serial ports found";
        const string SQL_OPEN = "1";
        const string FM = "FM";
        const string NFM = "NFM";
        const string WFMB = "WFMB";
        const string WFM = "WFM";
        const int GLG_MSG_MIN_LEN = 16;
        const int GLG_FREQ = 1;
        const int GLG_MODE = 2;
        const int GLG_SQL = 8;
        const int GLG_LEN = 10;

        TcpClient tcpClient = new TcpClient();

        DetectorType _detectorType;
        Freq _freq;
        //Freq _centerFreq;

        private delegate void SetTextDeleg(string text);

        public Form1()
        {
            InitializeComponent();
            _detectorType = new DetectorType
            {
                Command = "Set",
                Method = "DetectorType",
                Value = ""
            };
            _freq = new Freq
            {
                Command = "Set",
                Method = "Frequency",
                Value = 0
            };
            //_centerFreq = new Freq
            //{
            //    Command = "Set",
            //    Method = "CenterFrequency",
            //    Value = 0
            //};
            string[] ports = SerialPort.GetPortNames();
            if (ports.Length > 0)
            {
                serialPort1.PortName = ports[0];
            }
            else
            {
                buttonStart.Enabled = false;
                buttonStop.Enabled = false;
                textBoxScr.Text = NO_COM_PORT_MSG;
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            dataRX = dataRX + serialPort1.ReadExisting();
            if (rx)
            {
                if ((dataRX.Contains('\r')) && (!dataRX.Contains(GLG_SQL_CLOSED)))
                {
                    this.BeginInvoke(new SetTextDeleg(ser_DataReceived), new object[] { dataRX });
                }
                if (dataRX.Contains(GLG_SQL_CLOSED + "\r"))
                {
                    this.BeginInvoke(new SetTextDeleg(ser_DataReceived), new object[] { GLG_SQL_CLOSE_MSG });
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                rx = false;
                serialPort1.DiscardOutBuffer();
                serialPort1.DiscardInBuffer();
                serialPort1.DataReceived -= serialPort1_DataReceived;
            }
        }

        private void ser_DataReceived(string data)
        {
            textBoxScr.Text = string.Empty;
            if (rx)
            {
                textBoxScr.Text = data;
                if (data.Length > GLG_MSG_MIN_LEN)
                {
                    textBoxScr.Text = string.Empty;
                    string[] lines = data.Replace(" ", "").Split(',');
                    foreach (var line in lines)
                    {
                        if (line.Trim().Length > 0)
                        {
                            textBoxScr.Text = textBoxScr.Text + line + Environment.NewLine;
                        }
                    }
                    if (lines.Length == GLG_LEN)
                    {
                        if (lines[GLG_SQL].Equals(SQL_OPEN))
                        {
                            string fs = string.Empty;
                            long f;
                            if (Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator.Equals(","))
                            {
                                fs = lines[GLG_FREQ].Replace('.', ',');
                            }
                            if (long.TryParse(fs, out f))
                            {
                                _freq.Value = f * 100;
                                _detectorType.Value = lines[GLG_MODE];
                                if (_detectorType.Value.Equals(FM))
                                {
                                    _detectorType.Value = NFM;
                                }
                                if (_detectorType.Value.Equals(WFMB))
                                {
                                    _detectorType.Value = WFM;
                                }
                                string detectorJSON = new JavaScriptSerializer().Serialize(_detectorType);
                                //string centerFreqJSON = new JavaScriptSerializer().Serialize(_centerFreq);
                                string freqJSON = new JavaScriptSerializer().Serialize(_freq);
                                textBoxScr.Text = textBoxScr.Text + detectorJSON + Environment.NewLine;
                                //textBoxScr.Text = textBoxScr.Text + centerFreqJSON + Environment.NewLine;
                                textBoxScr.Text = textBoxScr.Text + freqJSON + Environment.NewLine;

                                if ((tcpConnect) && (!freq.Equals(fs)))
                                {
                                    freq = fs;
                                    ASCIIEncoding ascii = new ASCIIEncoding();
                                    byte[] msg = ascii.GetBytes(detectorJSON);
                                    try
                                    {
                                        NetworkStream stream = tcpClient.GetStream();
                                        stream.Write(msg, 0, msg.Length);
                                        msg = ascii.GetBytes(freqJSON);
                                        stream.Write(msg, 0, msg.Length);
                                    }
                                    catch (Exception ex)
                                    {
                                        textBoxScr.Text = textBoxScr.Text + ex.Message + Environment.NewLine;
                                    }
                                }
                            }
                        }
                    }
                }
                dataRX = string.Empty;
                serialPort1.Write(UNIDEN_CMD);
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            textBoxScr.Text = string.Empty;
            dataRX = string.Empty;
            freq = string.Empty;
            try
            {
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), APP_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            tcpConnect = true;
            try
            {
                if (!tcpClient.Client.Connected)
                {
                    tcpClient.Connect(IP, Convert.ToInt32(numericUpDownTcpPort.Value));
                }
            }
            catch (Exception ex)
            {
                tcpConnect = false;
                MessageBox.Show(ex.ToString(), APP_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            numericUpDownTcpPort.Enabled = false;
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
            rx = true;
            serialPort1.Write(UNIDEN_CMD);
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            rx = false;
            serialPort1.DiscardOutBuffer();
            serialPort1.DiscardInBuffer();
            tcpConnect = false;
            textBoxScr.Text = string.Empty;
            numericUpDownTcpPort.Enabled = true;
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
        }
    }
}
