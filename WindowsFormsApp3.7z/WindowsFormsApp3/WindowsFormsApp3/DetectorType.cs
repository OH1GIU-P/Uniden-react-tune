﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp3
{
    public class DetectorType
    {
        public string Command;
        public string Method;
        public string Value;
    }
}
