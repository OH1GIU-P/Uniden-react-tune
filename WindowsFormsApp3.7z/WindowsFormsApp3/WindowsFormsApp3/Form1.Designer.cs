﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.buttonStart = new System.Windows.Forms.Button();
            this.textBoxScr = new System.Windows.Forms.TextBox();
            this.buttonStop = new System.Windows.Forms.Button();
            this.numericUpDownTcpPort = new System.Windows.Forms.NumericUpDown();
            this.labelTcpPort = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTcpPort)).BeginInit();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 38400;
            this.serialPort1.PortName = "COM5";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(171, 28);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 2;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // textBoxScr
            // 
            this.textBoxScr.Location = new System.Drawing.Point(12, 72);
            this.textBoxScr.Multiline = true;
            this.textBoxScr.Name = "textBoxScr";
            this.textBoxScr.ReadOnly = true;
            this.textBoxScr.Size = new System.Drawing.Size(358, 281);
            this.textBoxScr.TabIndex = 1;
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(270, 28);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 3;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // numericUpDownTcpPort
            // 
            this.numericUpDownTcpPort.Location = new System.Drawing.Point(72, 28);
            this.numericUpDownTcpPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numericUpDownTcpPort.Name = "numericUpDownTcpPort";
            this.numericUpDownTcpPort.Size = new System.Drawing.Size(69, 20);
            this.numericUpDownTcpPort.TabIndex = 0;
            this.numericUpDownTcpPort.Value = new decimal(new int[] {
            3382,
            0,
            0,
            0});
            // 
            // labelTcpPort
            // 
            this.labelTcpPort.AutoSize = true;
            this.labelTcpPort.Location = new System.Drawing.Point(12, 28);
            this.labelTcpPort.Name = "labelTcpPort";
            this.labelTcpPort.Size = new System.Drawing.Size(54, 15);
            this.labelTcpPort.TabIndex = 5;
            this.labelTcpPort.Text = "TCP port";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 378);
            this.Controls.Add(this.labelTcpPort);
            this.Controls.Add(this.numericUpDownTcpPort);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.textBoxScr);
            this.Controls.Add(this.buttonStart);
            this.Name = "Form1";
            this.Text = "SDR# Uniden react tune";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTcpPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.TextBox textBoxScr;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.NumericUpDown numericUpDownTcpPort;
        private System.Windows.Forms.Label labelTcpPort;
    }
}

